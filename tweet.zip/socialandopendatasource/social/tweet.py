import tweepy

TWITTER_APP_KEY="sLT0Fre0TN5E5LM1bMwt6B6T8"
TWITTER_APP_SECRET="eOi1VEnvAxqkjNAVhKzq4yJrkLsi3Z38lM5QcozqxYtQ77Kz3l"
TWITTER_KEY="42841971-vDBAln1pdHCH9IiHSNiFgIH1BnLaIdF54EVw2AQWw"
TWITTER_SECRET="aODd1KGYvLUcL6sW7QymaBKiYbvUOWgMPe8cSpkAS3rBQ"

from pymongo import MongoClient
client = MongoClient('mongodb://localhost:27017/')
db = client.social
collection = db["twitter"]

class StreamListener(tweepy.StreamListener):
    def on_status(self, status):
        user_id = status.user.id
        twitter_handle = status.user.screen_name
        friends_count = status.user.friends_count
        followers_count = status.user.followers_count
        favourites_count = status.user.favourites_count
        statuses_count = status.user.statuses_count
        created_at = status.created_at
        description = status.text
        medias = []
        if 'media' in status.entities:
            for image in  status.entities['media']:
                link = image['media_url']
                medias.append(link)

        media = ",".join(medias)

        jsonData  = {
            "user_id" : user_id,
            "twitter_handle" : twitter_handle,
            "description" : description,
            "friends_count":friends_count,
            "followers_count" : followers_count,
            "favourites_count" : favourites_count,
            "statuses_count" : statuses_count,
            "created_at" : created_at,
            "media" : media
        }

        collection.insert_one(jsonData)
        return

    def on_error(self, status_code):
        if status_code == 420:
            return False

def start_streaming_tweets_to_mongo():
    auth = tweepy.OAuthHandler(TWITTER_APP_KEY, TWITTER_APP_SECRET)
    auth.set_access_token(TWITTER_KEY, TWITTER_SECRET)
    api = tweepy.API(auth)

    stream_listener = StreamListener()
    stream = tweepy.Stream(auth=api.auth, listener=stream_listener)
    stream.filter(track=["ronaldo","messi"])

def stop_streaming():
    stream_listener = StreamListener()
    stream_listener.on_error(420)



import csv

from django.shortcuts import render, redirect
from bson.json_util import dumps


from pymongo import MongoClient
from social.tweet import start_streaming_tweets_to_mongo
client = MongoClient('mongodb://localhost:27017/')

twitter_headers = [
    "user_id",
    "twitter_handle" ,
    "description" ,
    "friends_count",
    "followers_count" ,
    "favourites_count",
    "statuses_count",
    "created_at",
    "media"
]


def getDataFromTwitter():
    db = client.social
    collection = db["twitter"]
    tweets = []
    for i in collection.find():
        data =  {
            "user_id" : i["user_id"],
            "twitter_handle" : i["twitter_handle"],
            "description" : i["description"],
            "friends_count" : i["friends_count"],
            "followers_count"  : i["followers_count"],
            "favourites_count" : i["favourites_count"],
            "statuses_count" : i["statuses_count"],
            "created_at": i["created_at"],
            "media" : i["media"]
        }
        tweets.append(data)
    return tweets

def show(request):
    #start_streaming_tweets_to_mongo()
    out = getDataFromTwitter()
    return render(request, "show.html", {'data': out, "headers" : twitter_headers})
